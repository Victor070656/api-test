<?php
// header('Access-Control-Allow-Origin: *');
// header('Access-Control-Alow-Headers: *');
$conn = mysqli_connect("localhost", "root", "", "api");


    if($_POST){
        $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "INSERT INTO api_test(id, sname, email) VALUES('', '$name', '$email')";
   $res = mysqli_query($conn, $sql);
    echo "<script>
        window.location.href = 'http://localhost:3000';
    </script>";
    }

?>